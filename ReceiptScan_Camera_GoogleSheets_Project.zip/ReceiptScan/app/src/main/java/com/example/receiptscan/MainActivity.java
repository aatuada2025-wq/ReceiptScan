package com.example.receiptscan;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.*;

public class MainActivity extends AppCompatActivity {
    private static final int CAMERA_REQUEST = 101;
    private int captureMode = 0; // 0 = reference receipt, 1 = GCash profile
    private Bitmap capturedBitmap;
    private Uri capturedImageUri;
    private TextView status;
    private EditText reference, nameField, mobileField, sheetUrl;
    private Button scanButton, profileButton, saveButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // Immersive full-screen interface; swipe from an edge to reveal system bars.
        getWindow().getDecorView().setSystemUiVisibility(
            android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
            | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        buildUi();
    }

    private void buildUi() {
        // Spacious, fixed full-screen layout: no ScrollView; content uses the available screen area.
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(0), dp(12), dp(5));
        root.setBackgroundColor(0xFFF7FBFE);

        // Centered GCash × ChooksToGo collaboration header, with 30sp top margin.
        ImageView partnershipHeader = new ImageView(this);
        partnershipHeader.setImageResource(com.example.receiptscan.R.drawable.partnership_header);
        partnershipHeader.setScaleType(ImageView.ScaleType.FIT_CENTER);
        partnershipHeader.setAdjustViewBounds(false);
        LinearLayout.LayoutParams headerParams = params(-1, dp(120));
        headerParams.topMargin = sp(30);
        headerParams.bottomMargin = dp(3);
        root.addView(partnershipHeader, headerParams);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(android.view.Gravity.CENTER);
        hero.setPadding(dp(10), dp(5), dp(10), dp(6));
        hero.setBackground(roundRect(0xFFEAF5FF, dp(18), 0x00000000, 0));
        LinearLayout.LayoutParams heroP = params(-1, -2); heroP.bottomMargin = dp(6); root.addView(hero, heroP);
        TextView receiptIcon = new TextView(this); receiptIcon.setText("▤"); receiptIcon.setTextSize(27);
        receiptIcon.setTextColor(0xFF079AA7); receiptIcon.setGravity(android.view.Gravity.CENTER); hero.addView(receiptIcon);
        TextView heading = new TextView(this); heading.setText("Scan GCash Receipt"); heading.setTextSize(24);
        heading.setTypeface(null, 1); heading.setTextColor(0xFF103879); heading.setGravity(android.view.Gravity.CENTER);
        hero.addView(heading);
        TextView subtitle = new TextView(this);
        subtitle.setText("Scan the reference number, enter name and mobile, then save.");
        subtitle.setTextSize(13); subtitle.setTextColor(0xFF31536D); subtitle.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams subP = params(-1, -2); subP.topMargin = dp(4); hero.addView(subtitle, subP);

        addLabel(root, "▤  Reference No. (OCR only)");
        reference = makeField("Scan the GCash receipt", 27);
        LinearLayout.LayoutParams refP = params(-1, dp(58)); refP.bottomMargin = sp(20); root.addView(reference, refP);

        addLabel(root, "Name");
        nameField = makeField("Capture or enter name", 20);
        root.addView(nameField, params(-1, dp(48)));
        addLabel(root, "Mobile Number");
        mobileField = makeField("Capture or enter mobile number", 20);
        mobileField.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        root.addView(mobileField, params(-1, dp(48)));

        addLabel(root, "Google Sheets URL");
        sheetUrl = makeField("", 17);
        sheetUrl.setSingleLine(true);
        sheetUrl.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        sheetUrl.setText(getPreferences(MODE_PRIVATE).getString("sheet_url", ""));
        root.addView(sheetUrl, params(-1, dp(50)));

        scanButton = new Button(this); scanButton.setText("▣  Scan Receipt"); styleButton(scanButton);
        scanButton.setBackground(roundRect(0xFF087DEB, dp(18), 0x00000000, 0));
        scanButton.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams scanP = params(-1, dp(58)); scanP.topMargin = dp(7); root.addView(scanButton, scanP);
        scanButton.setOnClickListener(v -> { captureMode = 0; captureReceipt(); });

        profileButton = new Button(this); profileButton.setText("◎  Capture Name & Mobile Number"); styleButton(profileButton);
        profileButton.setTextSize(19);
        profileButton.setBackground(roundRect(0xFF1769D2, dp(18), 0x00000000, 0));
        profileButton.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams profileP = params(-1, dp(54)); profileP.topMargin = dp(6); root.addView(profileButton, profileP);
        profileButton.setOnClickListener(v -> { captureMode = 1; captureReceipt(); });

        saveButton = new Button(this); saveButton.setText("▤  Save to Google Sheets"); styleButton(saveButton);
        saveButton.setBackground(roundRect(0xFF08A66A, dp(18), 0x00000000, 0));
        saveButton.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams saveP = params(-1, dp(58)); saveP.topMargin = dp(6); root.addView(saveButton, saveP);
        saveButton.setOnClickListener(v -> saveToSheets());

        status = new TextView(this); status.setText("Ready. Tap Scan Receipt to begin.");
        status.setTextColor(0xFF087A49); status.setTextSize(14); status.setPadding(dp(12), dp(5), dp(12), dp(5));
        status.setBackground(roundRect(0xFFDDF8EB, dp(16), 0x00000000, 0));
        LinearLayout.LayoutParams st = params(-1, -2); st.topMargin = dp(5); root.addView(status, st);

        TextView byline = new TextView(this);
        byline.setText("by Ash AT"); byline.setTextSize(13); byline.setTextColor(0xFF68778A);
        byline.setGravity(android.view.Gravity.RIGHT | android.view.Gravity.CENTER_VERTICAL);
        byline.setPadding(0, dp(2), dp(4), 0);
        LinearLayout.LayoutParams bylineP = params(-1, dp(24)); bylineP.topMargin = dp(2); root.addView(byline, bylineP);

        setContentView(root);
    }

    private EditText makeField(String hint, int textSize) {
        EditText field = new EditText(this);
        field.setTextColor(0xFF101828); field.setHintTextColor(0xFF8795A8);
        field.setTextSize(textSize); field.setMinHeight(dp(60));
        field.setPadding(dp(14), dp(12), dp(14), dp(12)); field.setHint(hint);
        field.setBackground(roundRect(0xFFFFFFFF, dp(14), 0xFF69B3FF, dp(2)));
        return field;
    }

    private android.graphics.drawable.GradientDrawable roundRect(int fill, int radius, int stroke, int strokeWidth) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(fill); d.setCornerRadius(radius);
        if (strokeWidth > 0) d.setStroke(strokeWidth, stroke);
        return d;
    }

    private void addLabel(LinearLayout root, String text) {
        TextView label = new TextView(this); label.setText(text); label.setTextColor(0xFF000000);
        label.setTextSize(17); label.setTypeface(null, 1); label.setPadding(0, dp(2), 0, dp(2)); label.setTextColor(0xFF103879);
        LinearLayout.LayoutParams p = params(-1, -2); p.topMargin = dp(4); root.addView(label, p);
    }

    private void captureReceipt() {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) == null) {
            status.setText("No camera app is available on this phone.");
            return;
        }
        try {
            File pictures = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "receipts");
            if (!pictures.exists() && !pictures.mkdirs()) {
                status.setText("Could not prepare storage for the receipt photo.");
                return;
            }
            File photo = File.createTempFile("receipt_", ".jpg", pictures);
            capturedImageUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photo);
            intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, capturedImageUri);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, CAMERA_REQUEST);
            status.setText(captureMode == 0 ? "Capture the GCash payment receipt." : "Capture the GCash profile screen.");
        } catch (IOException e) {
            status.setText("Could not prepare camera capture. Please try again.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CAMERA_REQUEST) return;
        if (resultCode != Activity.RESULT_OK || capturedImageUri == null) {
            status.setText("Capture cancelled. Tap Capture Receipt to try again.");
            return;
        }
        try (java.io.InputStream input = getContentResolver().openInputStream(capturedImageUri)) {
            capturedBitmap = BitmapFactory.decodeStream(input);
            if (capturedBitmap != null) {
                scanButton.setEnabled(true);
                status.setText("Photo captured. Reading text now…");
                if (captureMode == 0) { reference.setText(""); scanImage(); }
                else scanProfileImage();
            } else {
                status.setText("The photo could not be opened. Please capture it again.");
            }
        } catch (IOException | SecurityException e) {
            status.setText("Could not read the captured photo. Please try again.");
        }
    }

    private void scanProfileImage() {
        if (capturedBitmap == null) return;
        profileButton.setEnabled(false); status.setText("Reading name and mobile number…");
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(InputImage.fromBitmap(capturedBitmap, 0))
            .addOnSuccessListener(result -> {
                String full = result.getText();
                String mobile = "";
                Matcher phone = Pattern.compile("(?<!\\d)(?:\\+?63|0)?9\\d(?:[ \\-]*\\d){8}(?!\\d)").matcher(full);
                if (phone.find()) {
                    mobile = phone.group().replaceAll("[ \\-]", "");
                    if (mobile.startsWith("+63")) mobile = "0" + mobile.substring(3);
                    else if (mobile.startsWith("63") && mobile.length() == 12) mobile = "0" + mobile.substring(2);
                }
                String name = "";
                String[] lines = full.split("\n");
                for (String line : lines) {
                    String t = line.trim().replaceAll("\\s{2,}", " ");
                    // Ignore avatar initials, phone numbers, and common GCash menu labels.
                    if (t.length() < 5 || t.matches(".*\\d.*") || !t.matches(".*[A-Za-z].*")
                        || t.matches("(?i)^[A-Z]{1,3}$")
                        || t.matches("(?i).*(fully verified|view benefits|security center|settings|linked accounts|my qr codes|profile limits|subscription center|terms and conditions|gscores?).*")) continue;
                    // Prefer a plausible full name (two or more words) over isolated profile text.
                    if (t.matches("(?i)[A-Z][A-Za-z.'-]+(?:\\s+[A-Z][A-Za-z.'-]+)+.*")) { name = t; break; }
                    if (name.isEmpty()) name = t;
                }
                if (!name.isEmpty()) nameField.setText(name);
                if (!mobile.isEmpty()) mobileField.setText(mobile);
                status.setText("Profile scan complete. Check the name and mobile number.");
                if (name.isEmpty() || mobile.isEmpty()) Toast.makeText(this, "Some details were not detected. Please type them manually.", Toast.LENGTH_LONG).show();
                profileButton.setEnabled(true);
            })
            .addOnFailureListener(e -> { status.setText("Could not read profile. Try a clearer photo."); profileButton.setEnabled(true); });
    }

    private void scanImage() {
        if (capturedBitmap == null) return;
        scanButton.setEnabled(false); status.setText("Reading receipt…");
        InputImage image = InputImage.fromBitmap(capturedBitmap, 0);
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
            .addOnSuccessListener(result -> {
                String allText = result.getText();
                reference.setText(findReference(result));
                status.setText("Scan complete. Check the reference number before saving.");
                scanButton.setEnabled(true);
                if (reference.getText().toString().trim().isEmpty())
                    Toast.makeText(this, "Reference number was not detected. You can type it manually.", Toast.LENGTH_LONG).show();
            })
            .addOnFailureListener(e -> { status.setText("Could not read image. Try capturing it again in good light."); scanButton.setEnabled(true); });
    }

    private void saveToSheets() {
        String ref = reference.getText().toString().trim();
        String endpoint = sheetUrl.getText().toString().trim();
        if (endpoint.isEmpty()) endpoint = getPreferences(MODE_PRIVATE).getString("sheet_url", "");
        if (ref.isEmpty()) {
            Toast.makeText(this, "Scan or enter the reference number first.", Toast.LENGTH_LONG).show(); return;
        }
        if (!endpoint.startsWith("https://script.google.com/")) {
            Toast.makeText(this, "Paste your deployed Google Apps Script Web App URL first.", Toast.LENGTH_LONG).show(); return;
        }

        String name = nameField.getText().toString().trim();
        String mobile = mobileField.getText().toString().trim();
        if (name.isEmpty()) {
            nameField.setError("Capture or enter your name first.");
            Toast.makeText(this, "Capture or enter your name first.", Toast.LENGTH_LONG).show();
            return;
        }
        if (mobile.isEmpty()) {
            mobileField.setError("Capture or enter your mobile number first.");
            Toast.makeText(this, "Capture or enter your mobile number first.", Toast.LENGTH_LONG).show();
            return;
        }
        saveReceiptToSheets(name, mobile, ref, endpoint);
    }

    private void saveReceiptToSheets(String name, String mobile, String ref, String endpointUrl) {
        getPreferences(MODE_PRIVATE).edit().putString("sheet_url", endpointUrl).apply();
        saveButton.setEnabled(false); status.setText("Saving to Google Sheets…");
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                JSONObject payload = new JSONObject();
                payload.put("name", name);
                payload.put("mobileNumber", mobile);
                payload.put("referenceCode", ref);
                conn = (HttpURLConnection) new URL(endpointUrl).openConnection();
                conn.setRequestMethod("POST"); conn.setConnectTimeout(15000); conn.setReadTimeout(15000);
                conn.setDoOutput(true); conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = conn.getOutputStream()) { os.write(body); }
                int code = conn.getResponseCode();
                runOnUiThread(() -> {
                    if (code >= 200 && code < 400) {
                        status.setText("Saved successfully! Data has been sent to Google Sheets.");
                        reference.setText(""); nameField.setText(""); mobileField.setText("");
                        capturedBitmap = null;
                        Toast.makeText(this, "Saved to Google Sheets. Reference cleared; URL kept.", Toast.LENGTH_LONG).show();
                    } else status.setText("Save failed (HTTP " + code + "). Check Web App deployment and URL.");
                    saveButton.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> { status.setText("Could not connect. Check internet and the Web App URL."); saveButton.setEnabled(true); });
            } finally { if (conn != null) conn.disconnect(); }
        }).start();
    }

    private void styleButton(Button button) {
        button.setTextSize(23);
        button.setAllCaps(false);
        button.setMinHeight(dp(64));
        button.setPadding(dp(16), dp(14), dp(16), dp(14));
    }

    private String findReference(com.google.mlkit.vision.text.Text result) {
        // Locate the actual "Reference No." label first, then read only text on its
        // row/right side. This avoids accidentally returning the day (e.g. 20) from
        // the date line above the reference number.
        java.util.ArrayList<com.google.mlkit.vision.text.Text.Line> lines = new java.util.ArrayList<>();
        for (com.google.mlkit.vision.text.Text.TextBlock block : result.getTextBlocks()) {
            lines.addAll(block.getLines());
        }
        Pattern label = Pattern.compile("(?i)\\b(?:reference\\s*(?:no\\.?|number|#|code)|ref\\s*(?:no\\.?|number|#|code)|reference\\s*id)\\b");
        int labelIndex = -1;
        android.graphics.Rect labelBox = null;
        for (int i = 0; i < lines.size(); i++) {
            android.graphics.Rect b = lines.get(i).getBoundingBox();
            if (label.matcher(lines.get(i).getText()).find() && b != null) {
                labelIndex = i;
                labelBox = b;
                break;
            }
        }
        if (labelIndex < 0 || labelBox == null) return "";

        // If ML Kit put the label and number on the same line, take the longest
        // numeric sequence after the label (no fixed digit count).
        String labelLine = lines.get(labelIndex).getText();
        Matcher lm = Pattern.compile("(?i)(?:reference\\s*(?:no\\.?|number|#|code)?|ref\\s*(?:no\\.?|number|#|code)?)").matcher(labelLine);
        if (lm.find()) {
            String sameLine = lastUsefulNumber(labelLine.substring(lm.end()));
            if (sameLine.length() >= 3) return sameLine;
        }

        String best = "";
        int bestScore = Integer.MAX_VALUE;
        for (int i = 0; i < lines.size(); i++) {
            if (i == labelIndex) continue;
            com.google.mlkit.vision.text.Text.Line line = lines.get(i);
            android.graphics.Rect b = line.getBoundingBox();
            if (b == null) continue;
            String t = line.getText();
            // Never use text that looks like the date, amount, or transaction details.
            if (t.matches("(?i).*(date|time|amount|total|paid|mobile|phone|oct|jan|feb|mar|apr|may|jun|jul|aug|sep|nov|dec).*")) continue;
            int vertical = Math.abs(b.centerY() - labelBox.centerY());
            int rowTolerance = Math.max(labelBox.height(), b.height()) * 2;
            boolean sameRow = vertical <= rowTolerance;
            boolean toRight = b.left >= labelBox.left + labelBox.width() / 2;
            // Do not search arbitrary lines far below the label: ad text can contain numbers.
            if (!sameRow || !toRight) continue;

            Matcher dm = Pattern.compile("(?<!\\d)(\\d(?:[ \\t-]*\\d)*)(?!\\d)").matcher(t);
            while (dm.find()) {
                String value = dm.group(1).replaceAll("[^0-9]", "");
                if (value.length() < 3) continue; // ignore isolated OCR fragments like "20"
                int score = vertical * 10 + Math.max(0, 20 - value.length()) * 3 + Math.max(0, b.left - labelBox.right) / 4;
                if (score < bestScore) { bestScore = score; best = value; }
            }
        }
        if (!best.isEmpty()) return best;

        // Fallback: if OCR split the reference into several adjacent text elements,
        // join numeric elements to the right of the label on the same visual row.
        java.util.ArrayList<com.google.mlkit.vision.text.Text.Element> elements = new java.util.ArrayList<>();
        for (com.google.mlkit.vision.text.Text.TextBlock block : result.getTextBlocks()) {
            for (com.google.mlkit.vision.text.Text.Line line : block.getLines()) {
                for (com.google.mlkit.vision.text.Text.Element element : line.getElements()) {
                    android.graphics.Rect eb = element.getBoundingBox();
                    if (eb == null || eb.left < labelBox.left + labelBox.width() / 2) continue;
                    if (Math.abs(eb.centerY() - labelBox.centerY()) <= Math.max(labelBox.height(), eb.height()) * 2
                            && element.getText().matches("[0-9][0-9 -]*")) elements.add(element);
                }
            }
        }
        java.util.Collections.sort(elements, (a, b) -> a.getBoundingBox().left - b.getBoundingBox().left);
        StringBuilder joined = new StringBuilder();
        int previousRight = -1;
        for (com.google.mlkit.vision.text.Text.Element e : elements) {
            android.graphics.Rect eb = e.getBoundingBox();
            if (previousRight >= 0 && eb.left - previousRight > Math.max(12, eb.height() * 2)) {
                String v = joined.toString().replaceAll("[^0-9]", "");
                if (v.length() >= 3) return v;
                joined.setLength(0);
            }
            joined.append(e.getText());
            previousRight = eb.right;
        }
        String joinedValue = joined.toString().replaceAll("[^0-9]", "");
        return joinedValue.length() >= 3 ? joinedValue : "";
    }

    private String lastUsefulNumber(String text) {
        Pattern p = Pattern.compile("(?<!\\d)(\\d(?:[ \t-]*\\d)*)(?!\\d)");
        Matcher m = p.matcher(text);
        String best = "";
        while (m.find()) {
            String value = m.group(1).replaceAll("[^0-9]", "");
            // Avoid returning a single digit from a date fragment or a currency amount.
            if (value.length() > best.length()) best = value;
        }
        return best;
    }

    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private int sp(int n) { return (int)(n * getResources().getDisplayMetrics().scaledDensity + 0.5f); }
}
