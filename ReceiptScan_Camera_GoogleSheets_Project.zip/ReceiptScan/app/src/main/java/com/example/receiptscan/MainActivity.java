package com.example.receiptscan;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.*;

public class MainActivity extends AppCompatActivity {
    private static final int CAMERA_REQUEST = 101;
    private Bitmap capturedBitmap;
    private Uri capturedImageUri;
    private TextView status;
    private EditText reference, dateTime, sheetUrl;
    private Button scanButton, saveButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // Immersive full-screen interface; swipe from an edge to reveal system bars.
        getWindow().getDecorView().setSystemUiVisibility(
            android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
            | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        root.setBackgroundColor(0xFFF6F8F8);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("GCash x CTG"); title.setTextSize(34);
        title.setTextColor(0xFF086F68); title.setTypeface(null, 1); root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Capture a receipt with your camera and extract the reference code and transaction date/time.");
        subtitle.setTextSize(18); subtitle.setTextColor(0xFF222222);
        LinearLayout.LayoutParams sp = params(-1, -2); sp.topMargin = dp(8); root.addView(subtitle, sp);

        Button capture = new Button(this); capture.setText("Capture Receipt"); styleButton(capture);
        LinearLayout.LayoutParams cp = params(-1, -2); cp.topMargin = dp(18); root.addView(capture, cp);
        capture.setOnClickListener(v -> captureReceipt());

        scanButton = new Button(this); scanButton.setText("Scan Captured Receipt"); styleButton(scanButton); scanButton.setEnabled(false);
        LinearLayout.LayoutParams bp = params(-1, -2); bp.topMargin = dp(8); root.addView(scanButton, bp);
        scanButton.setOnClickListener(v -> scanImage());

        addLabel(root, "Reference code");
        reference = new EditText(this); reference.setTextColor(0xFF000000); reference.setHintTextColor(0xFF666666);
        reference.setTextSize(26); reference.setMinHeight(dp(68)); reference.setPadding(dp(14), dp(16), dp(14), dp(16));
        reference.setHint("Reference number will appear here"); root.addView(reference, params(-1, -2));

        addLabel(root, "Transaction date and time");
        dateTime = new EditText(this); dateTime.setTextColor(0xFF000000); dateTime.setHintTextColor(0xFF666666);
        dateTime.setTextSize(26); dateTime.setMinHeight(dp(68)); dateTime.setPadding(dp(14), dp(16), dp(14), dp(16));
        dateTime.setHint("Date and time will appear here"); root.addView(dateTime, params(-1, -2));

        addLabel(root, "Google Sheets connection");
        sheetUrl = new EditText(this); sheetUrl.setTextColor(0xFF000000); sheetUrl.setHintTextColor(0xFF666666);
        sheetUrl.setTextSize(20); sheetUrl.setMinHeight(dp(64)); sheetUrl.setPadding(dp(14), dp(16), dp(14), dp(16));
        sheetUrl.setHint("Paste your Apps Script Web App URL here");
        sheetUrl.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        sheetUrl.setText(getPreferences(MODE_PRIVATE).getString("sheet_url", ""));
        root.addView(sheetUrl, params(-1, -2));

        TextView help = new TextView(this);
        help.setText("Setup instructions and Google Apps Script code are in GOOGLE_SHEETS_SETUP.txt.");
        help.setTextSize(15); help.setTextColor(0xFF333333);
        LinearLayout.LayoutParams hp = params(-1, -2); hp.topMargin = dp(4); root.addView(help, hp);

        saveButton = new Button(this); saveButton.setText("Save to Google Sheets"); styleButton(saveButton);
        LinearLayout.LayoutParams savep = params(-1, -2); savep.topMargin = dp(16); root.addView(saveButton, savep);
        saveButton.setOnClickListener(v -> saveToSheets());

        status = new TextView(this); status.setText("Ready. Tap Capture Receipt to begin.");
        status.setTextColor(0xFF222222); status.setTextSize(18);
        LinearLayout.LayoutParams st = params(-1, -2); st.topMargin = dp(12); root.addView(status, st);

        TextView note = new TextView(this);
        note.setText("Check extracted values before saving. Only the reference code and date/time are sent to your configured Google Sheet.");
        note.setTextSize(15); note.setTextColor(0xFF333333);
        LinearLayout.LayoutParams nt = params(-1, -2); nt.topMargin = dp(10); root.addView(note, nt);
        setContentView(scroll);
    }

    private void addLabel(LinearLayout root, String text) {
        TextView label = new TextView(this); label.setText(text); label.setTextColor(0xFF000000);
        label.setTextSize(20); label.setTypeface(null, 1);
        LinearLayout.LayoutParams p = params(-1, -2); p.topMargin = dp(16); root.addView(label, p);
    }

    private void captureReceipt() {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) == null) {
            status.setText("No camera app is available on this phone.");
            return;
        }
        try {
            File pictures = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "receipts");
            if (!pictures.exists() && !pictures.mkdirs()) {
                status.setText("Could not prepare storage for the receipt photo.");
                return;
            }
            File photo = File.createTempFile("receipt_", ".jpg", pictures);
            capturedImageUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photo);
            intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, capturedImageUri);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, CAMERA_REQUEST);
            status.setText("Camera opened. Take the receipt photo and confirm it.");
        } catch (IOException e) {
            status.setText("Could not prepare camera capture. Please try again.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CAMERA_REQUEST) return;
        if (resultCode != Activity.RESULT_OK || capturedImageUri == null) {
            status.setText("Capture cancelled. Tap Capture Receipt to try again.");
            return;
        }
        try (java.io.InputStream input = getContentResolver().openInputStream(capturedImageUri)) {
            capturedBitmap = BitmapFactory.decodeStream(input);
            if (capturedBitmap != null) {
                scanButton.setEnabled(true);
                status.setText("Receipt captured. Tap Scan Captured Receipt.");
                reference.setText(""); dateTime.setText("");
            } else {
                status.setText("The photo could not be opened. Please capture it again.");
            }
        } catch (IOException | SecurityException e) {
            status.setText("Could not read the captured photo. Please try again.");
        }
    }

    private void scanImage() {
        if (capturedBitmap == null) return;
        scanButton.setEnabled(false); status.setText("Reading receipt…");
        InputImage image = InputImage.fromBitmap(capturedBitmap, 0);
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
            .addOnSuccessListener(result -> {
                String allText = result.getText();
                reference.setText(findReference(allText)); dateTime.setText(findDateTime(allText));
                status.setText("Scan complete. Check the black text fields before saving.");
                scanButton.setEnabled(true);
                if (reference.getText().toString().trim().isEmpty() || dateTime.getText().toString().trim().isEmpty())
                    Toast.makeText(this, "Some information was not detected. You can type it manually.", Toast.LENGTH_LONG).show();
            })
            .addOnFailureListener(e -> { status.setText("Could not read image. Try capturing it again in good light."); scanButton.setEnabled(true); });
    }

    private void saveToSheets() {
        String ref = reference.getText().toString().trim();
        String dt = dateTime.getText().toString().trim();
        String endpoint = sheetUrl.getText().toString().trim();
        if (ref.isEmpty() || dt.isEmpty()) {
            Toast.makeText(this, "Enter or scan both fields first.", Toast.LENGTH_LONG).show(); return;
        }
        if (!endpoint.startsWith("https://script.google.com/")) {
            Toast.makeText(this, "Paste your deployed Google Apps Script Web App URL first.", Toast.LENGTH_LONG).show(); return;
        }
        getPreferences(MODE_PRIVATE).edit().putString("sheet_url", endpoint).apply();
        saveButton.setEnabled(false); status.setText("Saving to Google Sheets…");
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                JSONObject payload = new JSONObject(); payload.put("referenceCode", ref); payload.put("dateTime", dt);
                conn = (HttpURLConnection) new URL(endpoint).openConnection();
                conn.setRequestMethod("POST"); conn.setConnectTimeout(15000); conn.setReadTimeout(15000);
                conn.setDoOutput(true); conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = conn.getOutputStream()) { os.write(body); }
                int code = conn.getResponseCode();
                runOnUiThread(() -> {
                    if (code >= 200 && code < 400) {
                        status.setText("Request sent. Check your Google Sheet to confirm the new row.");
                        Toast.makeText(this, "Sent to Google Sheets", Toast.LENGTH_LONG).show();
                    } else status.setText("Save failed (HTTP " + code + "). Check Web App deployment and URL.");
                    saveButton.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> { status.setText("Could not connect. Check internet and the Web App URL."); saveButton.setEnabled(true); });
            } finally { if (conn != null) conn.disconnect(); }
        }).start();
    }

    private void styleButton(Button button) {
        button.setTextSize(22);
        button.setAllCaps(false);
        button.setMinHeight(dp(64));
        button.setPadding(dp(16), dp(14), dp(16), dp(14));
    }

    private String findReference(String text) {
        // Never guess from arbitrary numbers: that can incorrectly return the sender's mobile number.
        // Only accept a number explicitly following a reference/transaction-reference label.
        String[] lines = text.split("\\n");
        Pattern label = Pattern.compile("(?i)\\b(?:ref(?:erence)?\\s*(?:no\\.?|number|#|code)?|reference\\s*id)\\s*[:#.\\-]?\\s*(.*)");
        Pattern refDigits = Pattern.compile("(?<!\\d)(\\d{3,5}(?:[ \\t-]+\\d{2,6}){1,2})(?!\\d)");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            Matcher lm = label.matcher(line);
            if (!lm.find()) continue;

            String afterLabel = lm.group(1).trim();
            Matcher dm = refDigits.matcher(afterLabel);
            if (dm.find()) return dm.group(1).replaceAll("[ \\t-]+", " ").trim();

            // OCR may place the label on one line and the reference number on the next.
            // Only inspect the immediately following line, and only if it is not labeled as phone/date/amount.
            if (afterLabel.isEmpty() && i + 1 < lines.length) {
                String next = lines[i + 1].trim();
                if (!next.matches("(?i).*(mobile|phone|date|time|amount|total|sent via|\\+?63).*")) {
                    dm = refDigits.matcher(next);
                    if (dm.find()) return dm.group(1).replaceAll("[ \\t-]+", " ").trim();
                }
            }
        }
        // Intentionally return empty rather than mistaking the mobile number for the reference.
        return "";
    }

    private String findDateTime(String text) {
        String[] patterns = {
            "(?i)\\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\\s+\\d{1,2},?\\s+\\d{4}(?:\\s+\\d{1,2}:\\d{2}(?::\\d{2})?\\s*(?:AM|PM)?)?",
            "\\b\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4}(?:[, ]+\\d{1,2}:\\d{2}(?::\\d{2})?\\s*(?:AM|PM|am|pm)?)?",
            "\\b\\d{4}[/-]\\d{1,2}[/-]\\d{1,2}(?:[, ]+\\d{1,2}:\\d{2}(?::\\d{2})?\\s*(?:AM|PM|am|pm)?)?"
        };
        for (String p : patterns) { Matcher m = Pattern.compile(p).matcher(text); if (m.find()) return m.group().trim().replaceAll("\\s+", " "); }
        Matcher time = Pattern.compile("\\b\\d{1,2}:\\d{2}(?::\\d{2})?\\s*(?:AM|PM|am|pm)?\\b").matcher(text);
        return time.find() ? time.group().trim() : "";
    }
    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
}
