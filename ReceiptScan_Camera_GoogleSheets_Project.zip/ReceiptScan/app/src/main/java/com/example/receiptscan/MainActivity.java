package com.example.receiptscan;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.*;

public class MainActivity extends AppCompatActivity {
    private static final int CAMERA_REQUEST = 101;
    private Bitmap capturedBitmap;
    private Uri capturedImageUri;
    private TextView status;
    private EditText reference, dateTime, sheetUrl;
    private Button scanButton, saveButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // Immersive full-screen interface; swipe from an edge to reveal system bars.
        getWindow().getDecorView().setSystemUiVisibility(
            android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
            | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        buildUi();
    }

    private void buildUi() {
        // Spacious, fixed full-screen layout: no ScrollView; content uses the available screen area.
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(7), dp(14), dp(8));
        root.setBackgroundColor(0xFFF7FBFE);

        // Two-line branding keeps both names at 35sp while placing the chicken beside ChooksToGo.
        LinearLayout brandBlock = new LinearLayout(this);
        brandBlock.setOrientation(LinearLayout.VERTICAL);
        brandBlock.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams brandBlockParams = params(-1, dp(112));
        brandBlockParams.bottomMargin = dp(5);
        root.addView(brandBlock, brandBlockParams);

        LinearLayout firstBrandLine = new LinearLayout(this);
        firstBrandLine.setOrientation(LinearLayout.HORIZONTAL);
        firstBrandLine.setGravity(android.view.Gravity.CENTER);
        brandBlock.addView(firstBrandLine, params(-1, dp(43)));

        TextView gcash = new TextView(this);
        gcash.setText("GCash"); gcash.setTextSize(35); gcash.setTypeface(null, 1);
        gcash.setTextColor(0xFF0866D9);
        firstBrandLine.addView(gcash);
        TextView cross = new TextView(this);
        cross.setText("  ×  "); cross.setTextSize(35); cross.setTypeface(null, 1);
        cross.setTextColor(0xFF111827); firstBrandLine.addView(cross);

        LinearLayout secondBrandLine = new LinearLayout(this);
        secondBrandLine.setOrientation(LinearLayout.HORIZONTAL);
        secondBrandLine.setGravity(android.view.Gravity.CENTER);
        brandBlock.addView(secondBrandLine, params(-1, dp(66)));

        TextView ctg = new TextView(this);
        ctg.setText("ChooksToGo"); ctg.setTextSize(35); ctg.setTypeface(null, 1);
        ctg.setTextColor(0xFFE53935);
        ctg.setSingleLine(true);
        secondBrandLine.addView(ctg);

        ImageView chicken = new ImageView(this);
        chicken.setImageResource(com.example.receiptscan.R.drawable.chicken_header);
        chicken.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams chickenParams = new LinearLayout.LayoutParams(dp(116), dp(64));
        chickenParams.leftMargin = dp(8);
        secondBrandLine.addView(chicken, chickenParams);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(android.view.Gravity.CENTER);
        hero.setPadding(dp(10), dp(8), dp(10), dp(9));
        hero.setBackground(roundRect(0xFFEAF5FF, dp(18), 0x00000000, 0));
        LinearLayout.LayoutParams heroP = params(-1, -2); heroP.bottomMargin = dp(9); root.addView(hero, heroP);
        TextView receiptIcon = new TextView(this); receiptIcon.setText("▤"); receiptIcon.setTextSize(30);
        receiptIcon.setTextColor(0xFF079AA7); receiptIcon.setGravity(android.view.Gravity.CENTER); hero.addView(receiptIcon);
        TextView heading = new TextView(this); heading.setText("Scan GCash Receipt"); heading.setTextSize(25);
        heading.setTypeface(null, 1); heading.setTextColor(0xFF103879); heading.setGravity(android.view.Gravity.CENTER);
        hero.addView(heading);
        TextView subtitle = new TextView(this);
        subtitle.setText("Capture the required details and save to Google Sheets.");
        subtitle.setTextSize(14); subtitle.setTextColor(0xFF31536D); subtitle.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams subP = params(-1, -2); subP.topMargin = dp(4); hero.addView(subtitle, subP);

        addLabel(root, "▤  Reference No.");
        reference = makeField("", 27);
        root.addView(reference, params(-1, dp(58)));

        addLabel(root, "▦  Transaction Date & Time");
        dateTime = makeField("", 25);
        root.addView(dateTime, params(-1, dp(58)));

        addLabel(root, "Google Sheets URL");
        sheetUrl = makeField("Paste your Apps Script Web App URL", 17);
        sheetUrl.setSingleLine(true);
        sheetUrl.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        sheetUrl.setText(getPreferences(MODE_PRIVATE).getString("sheet_url", ""));
        root.addView(sheetUrl, params(-1, dp(54)));

        scanButton = new Button(this); scanButton.setText("▣  Scan Receipt"); styleButton(scanButton);
        scanButton.setBackground(roundRect(0xFF087DEB, dp(18), 0x00000000, 0));
        scanButton.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams scanP = params(-1, dp(62)); scanP.topMargin = dp(10); root.addView(scanButton, scanP);
        scanButton.setOnClickListener(v -> captureReceipt());

        saveButton = new Button(this); saveButton.setText("▤  Save to Google Sheets"); styleButton(saveButton);
        saveButton.setBackground(roundRect(0xFF08A66A, dp(18), 0x00000000, 0));
        saveButton.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams saveP = params(-1, dp(62)); saveP.topMargin = dp(8); root.addView(saveButton, saveP);
        saveButton.setOnClickListener(v -> saveToSheets());

        status = new TextView(this); status.setText("Ready. Tap Scan Receipt to begin.");
        status.setTextColor(0xFF087A49); status.setTextSize(15); status.setPadding(dp(12), dp(7), dp(12), dp(7));
        status.setBackground(roundRect(0xFFDDF8EB, dp(16), 0x00000000, 0));
        LinearLayout.LayoutParams st = params(-1, -2); st.topMargin = dp(5); root.addView(status, st);

        TextView note = new TextView(this);
        note.setText("Check the extracted reference number and transaction date/time before saving.");
        note.setTextSize(12); note.setTextColor(0xFF425466);
        LinearLayout.LayoutParams nt = params(-1, -2); nt.topMargin = dp(6); root.addView(note, nt);
        setContentView(root);
    }

    private EditText makeField(String hint, int textSize) {
        EditText field = new EditText(this);
        field.setTextColor(0xFF101828); field.setHintTextColor(0xFF8795A8);
        field.setTextSize(textSize); field.setMinHeight(dp(60));
        field.setPadding(dp(14), dp(12), dp(14), dp(12)); field.setHint(hint);
        field.setBackground(roundRect(0xFFFFFFFF, dp(14), 0xFF69B3FF, dp(2)));
        return field;
    }

    private android.graphics.drawable.GradientDrawable roundRect(int fill, int radius, int stroke, int strokeWidth) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(fill); d.setCornerRadius(radius);
        if (strokeWidth > 0) d.setStroke(strokeWidth, stroke);
        return d;
    }

    private void addLabel(LinearLayout root, String text) {
        TextView label = new TextView(this); label.setText(text); label.setTextColor(0xFF000000);
        label.setTextSize(17); label.setTypeface(null, 1); label.setPadding(0, dp(2), 0, dp(2)); label.setTextColor(0xFF103879);
        LinearLayout.LayoutParams p = params(-1, -2); p.topMargin = dp(4); root.addView(label, p);
    }

    private void captureReceipt() {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) == null) {
            status.setText("No camera app is available on this phone.");
            return;
        }
        try {
            File pictures = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "receipts");
            if (!pictures.exists() && !pictures.mkdirs()) {
                status.setText("Could not prepare storage for the receipt photo.");
                return;
            }
            File photo = File.createTempFile("receipt_", ".jpg", pictures);
            capturedImageUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photo);
            intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, capturedImageUri);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, CAMERA_REQUEST);
            status.setText("Camera opened. Take the receipt photo and confirm it.");
        } catch (IOException e) {
            status.setText("Could not prepare camera capture. Please try again.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CAMERA_REQUEST) return;
        if (resultCode != Activity.RESULT_OK || capturedImageUri == null) {
            status.setText("Capture cancelled. Tap Capture Receipt to try again.");
            return;
        }
        try (java.io.InputStream input = getContentResolver().openInputStream(capturedImageUri)) {
            capturedBitmap = BitmapFactory.decodeStream(input);
            if (capturedBitmap != null) {
                scanButton.setEnabled(true);
                status.setText("Receipt captured. Reading the receipt now…");
                reference.setText(""); dateTime.setText("");
                scanImage();
            } else {
                status.setText("The photo could not be opened. Please capture it again.");
            }
        } catch (IOException | SecurityException e) {
            status.setText("Could not read the captured photo. Please try again.");
        }
    }

    private void scanImage() {
        if (capturedBitmap == null) return;
        scanButton.setEnabled(false); status.setText("Reading receipt…");
        InputImage image = InputImage.fromBitmap(capturedBitmap, 0);
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
            .addOnSuccessListener(result -> {
                String allText = result.getText();
                reference.setText(findReference(allText)); dateTime.setText(findDateTime(allText));
                status.setText("Scan complete. Check the black text fields before saving.");
                scanButton.setEnabled(true);
                if (reference.getText().toString().trim().isEmpty() || dateTime.getText().toString().trim().isEmpty())
                    Toast.makeText(this, "Some information was not detected. You can type it manually.", Toast.LENGTH_LONG).show();
            })
            .addOnFailureListener(e -> { status.setText("Could not read image. Try capturing it again in good light."); scanButton.setEnabled(true); });
    }

    private void saveToSheets() {
        String ref = reference.getText().toString().trim();
        String dt = dateTime.getText().toString().trim();
        String endpoint = sheetUrl.getText().toString().trim();
        if (endpoint.isEmpty()) endpoint = getPreferences(MODE_PRIVATE).getString("sheet_url", "");
        if (ref.isEmpty() || dt.isEmpty()) {
            Toast.makeText(this, "Enter or scan both fields first.", Toast.LENGTH_LONG).show(); return;
        }
        if (!endpoint.startsWith("https://script.google.com/")) {
            Toast.makeText(this, "Paste your deployed Google Apps Script Web App URL first.", Toast.LENGTH_LONG).show(); return;
        }
        final String endpointUrl = endpoint;
        getPreferences(MODE_PRIVATE).edit().putString("sheet_url", endpointUrl).apply();
        saveButton.setEnabled(false); status.setText("Saving to Google Sheets…");
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                JSONObject payload = new JSONObject(); payload.put("referenceCode", ref); payload.put("dateTime", dt);
                conn = (HttpURLConnection) new URL(endpointUrl).openConnection();
                conn.setRequestMethod("POST"); conn.setConnectTimeout(15000); conn.setReadTimeout(15000);
                conn.setDoOutput(true); conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = conn.getOutputStream()) { os.write(body); }
                int code = conn.getResponseCode();
                runOnUiThread(() -> {
                    if (code >= 200 && code < 400) {
                        status.setText("Saved successfully! Data has been sent to Google Sheets.");
                        reference.setText("");
                        dateTime.setText("");
                        capturedBitmap = null;
                        Toast.makeText(this, "Saved to Google Sheets. Reference and date/time cleared.", Toast.LENGTH_LONG).show();
                    } else status.setText("Save failed (HTTP " + code + "). Check Web App deployment and URL.");
                    saveButton.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> { status.setText("Could not connect. Check internet and the Web App URL."); saveButton.setEnabled(true); });
            } finally { if (conn != null) conn.disconnect(); }
        }).start();
    }

    private void styleButton(Button button) {
        button.setTextSize(23);
        button.setAllCaps(false);
        button.setMinHeight(dp(64));
        button.setPadding(dp(16), dp(14), dp(16), dp(14));
    }

    private String findReference(String text) {
        // Never guess from arbitrary numbers: that can incorrectly return the sender's mobile number.
        // Only accept a number explicitly following a reference/transaction-reference label.
        String[] lines = text.split("\\n");
        Pattern label = Pattern.compile("(?i)\\b(?:ref(?:erence)?\\s*(?:no\\.?|number|#|code)?|reference\\s*id)\\s*[:#.\\-]?\\s*(.*)");
        Pattern refDigits = Pattern.compile("(?<!\\d)(\\d(?:[ \\t-]?\\d){7,19})(?!\\d)");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            Matcher lm = label.matcher(line);
            if (!lm.find()) continue;

            String afterLabel = lm.group(1).trim();
            Matcher dm = refDigits.matcher(afterLabel);
            if (dm.find()) return dm.group(1).replaceAll("[^0-9]", "");

            // OCR may place the label on one line and the reference number on the next.
            // Only inspect the immediately following line, and only if it is not labeled as phone/date/amount.
            if (afterLabel.isEmpty() && i + 1 < lines.length) {
                String next = lines[i + 1].trim();
                if (!next.matches("(?i).*(mobile|phone|date|time|amount|total|sent via|\\+?63).*")) {
                    dm = refDigits.matcher(next);
                    if (dm.find()) return dm.group(1).replaceAll("[^0-9]", "");
                }
            }
        }
        // Intentionally return empty rather than mistaking the mobile number for the reference.
        return "";
    }

    private String findDateTime(String text) {
        String[] patterns = {
            "(?i)\\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\\s+\\d{1,2},?\\s+\\d{4}(?:\\s+\\d{1,2}:\\d{2}(?::\\d{2})?\\s*(?:AM|PM)?)?",
            "\\b\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4}(?:[, ]+\\d{1,2}:\\d{2}(?::\\d{2})?\\s*(?:AM|PM|am|pm)?)?",
            "\\b\\d{4}[/-]\\d{1,2}[/-]\\d{1,2}(?:[, ]+\\d{1,2}:\\d{2}(?::\\d{2})?\\s*(?:AM|PM|am|pm)?)?"
        };
        for (String p : patterns) { Matcher m = Pattern.compile(p).matcher(text); if (m.find()) return m.group().trim().replaceAll("\\s+", " "); }
        Matcher time = Pattern.compile("\\b\\d{1,2}:\\d{2}(?::\\d{2})?\\s*(?:AM|PM|am|pm)?\\b").matcher(text);
        return time.find() ? time.group().trim() : "";
    }
    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
}
