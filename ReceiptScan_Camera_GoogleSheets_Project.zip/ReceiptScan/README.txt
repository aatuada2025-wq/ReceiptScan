ReceiptScan Android project - camera and Google Sheets edition
Features: camera capture, on-device ML Kit text recognition, editable black text fields, and Save to Google Sheets.
See GOOGLE_SHEETS_SETUP.txt for connecting a spreadsheet.

Build APK: Open this folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
APK output: app/build/outputs/apk/debug/app-debug.apk
This ZIP is Android source code, not a compiled APK. OCR results should be checked against the receipt.
