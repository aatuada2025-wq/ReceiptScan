ReceiptScan Android project - camera and Google Sheets edition
Features: camera capture, on-device ML Kit text recognition, editable receipt fields, name prompt before saving, and Save to Google Sheets.
See GOOGLE_SHEETS_SETUP.txt for connecting a spreadsheet.

Build APK: Open this folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
APK output: app/build/outputs/apk/debug/app-debug.apk
This ZIP is Android source code, not a compiled APK. OCR results should be checked against the receipt.

Latest update: extracts recipient name (including masked dots/ellipsis) and Philippine mobile number in addition to reference code and transaction name and mobile number in the save popup. Update and redeploy the Apps Script in GOOGLE_SHEETS_SETUP.txt to save all four fields.

Latest UI update: recipient-name field removed. The app now captures Mobile Number, Reference No., and Transaction Date & Time only, with approximately 20sp vertical spacing between fields and a right-aligned “by Ash AT” footer.

Latest save update: tapping Save opens an Enter Your Name popup. The app sends Name, Mobile Number, Reference No., and Transaction Date & Time to Google Sheets; the Apps Script setup now writes those fields plus Saved At. Redeploy the updated Apps Script as a new version.
